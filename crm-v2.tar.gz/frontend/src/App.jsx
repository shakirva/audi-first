import { useState, useEffect } from 'react';
import { getClients, addClient, updateClient, importExcel, importVCF, login } from './api';
import { Users, Upload, Plus, Phone, Mail, Package, Search, Save, X, Activity, UserPlus, Filter, FileSpreadsheet, Contact, LogOut, Lock } from 'lucide-react';

function App() {
  const [token, setToken] = useState(localStorage.getItem('crm_token') || null);
  const [user, setUser] = useState(JSON.parse(localStorage.getItem('crm_user') || 'null'));
  
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingClient, setEditingClient] = useState(null);
  const [search, setSearch] = useState('');
  
  const [form, setForm] = useState({ name: '', phone: '', email: '', package: 'Standard', status: 'Lead', notes: '' });
  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  const [loginError, setLoginError] = useState('');

  useEffect(() => {
    if (token) fetchClients();
  }, [token]);

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoginError('');
    try {
      const { data } = await login(loginForm);
      localStorage.setItem('crm_token', data.token);
      localStorage.setItem('crm_user', JSON.stringify(data.user));
      setToken(data.token);
      setUser(data.user);
    } catch (err) {
      setLoginError('Invalid email or password');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('crm_token');
    localStorage.removeItem('crm_user');
    setToken(null);
    setUser(null);
    setClients([]);
  };

  const fetchClients = async () => {
    try {
      setLoading(true);
      const { data } = await getClients();
      setClients(data);
    } catch (err) {
      if (err.response?.status === 401) handleLogout();
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (editingClient) {
      await updateClient(editingClient.id, form);
    } else {
      await addClient(form);
    }
    setShowAddModal(false);
    setEditingClient(null);
    setForm({ name: '', phone: '', email: '', package: 'Standard', status: 'Lead', notes: '' });
    fetchClients();
  };

  const handleFileUpload = async (e, type) => {
    const file = e.target.files[0];
    if (!file) return;
    
    const formData = new FormData();
    formData.append('file', file);
    
    try {
      if (type === 'excel') await importExcel(formData);
      else await importVCF(formData);
      alert('Import successful!');
      fetchClients();
    } catch (err) {
      alert('Failed to import file');
    }
    e.target.value = null;
  };

  const openEdit = (client) => {
    setForm(client);
    setEditingClient(client);
    setShowAddModal(true);
  };

  const allStatuses = [
    'Lead', 'Contacted', 'Follow-up', 'Interested', 'Not Answered',
    'Scheduled Meeting', 'Conducted Meeting', 'Advance Got', 'Converted', 'Completed', 'Lost'
  ];

  const statusConfig = {
    'Lead': { bg: 'bg-slate-100', text: 'text-slate-700', border: 'border-slate-200' },
    'Contacted': { bg: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-200' },
    'Follow-up': { bg: 'bg-orange-50', text: 'text-orange-700', border: 'border-orange-200' },
    'Interested': { bg: 'bg-purple-50', text: 'text-purple-700', border: 'border-purple-200' },
    'Not Answered': { bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-200' },
    'Scheduled Meeting': { bg: 'bg-indigo-50', text: 'text-indigo-700', border: 'border-indigo-200' },
    'Conducted Meeting': { bg: 'bg-teal-50', text: 'text-teal-700', border: 'border-teal-200' },
    'Advance Got': { bg: 'bg-lime-50', text: 'text-lime-700', border: 'border-lime-200' },
    'Converted': { bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-200' },
    'Completed': { bg: 'bg-green-100', text: 'text-green-800', border: 'border-green-300' },
    'Lost': { bg: 'bg-rose-50', text: 'text-rose-700', border: 'border-rose-200' }
  };

  const filteredClients = clients.filter(c => 
    c.name.toLowerCase().includes(search.toLowerCase()) || 
    (c.phone && c.phone.includes(search))
  );

  if (!token) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white p-8 rounded-3xl shadow-xl w-full max-w-sm border border-slate-100">
          <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl mx-auto flex items-center justify-center mb-6 shadow-lg shadow-emerald-500/30">
            <Lock className="text-white" size={32} />
          </div>
          <h2 className="text-2xl font-bold text-center text-slate-800 mb-1">Welcome Back</h2>
          <p className="text-center text-slate-500 mb-6 text-sm">Sign in to Venueza Sales CRM</p>
          
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <input type="email" required placeholder="Email address" value={loginForm.email} onChange={e => setLoginForm({...loginForm, email: e.target.value})} className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none" />
            </div>
            <div>
              <input type="password" required placeholder="Password" value={loginForm.password} onChange={e => setLoginForm({...loginForm, password: e.target.value})} className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none" />
            </div>
            {loginError && <p className="text-red-500 text-sm text-center font-medium">{loginError}</p>}
            <button type="submit" className="w-full bg-slate-800 text-white p-4 rounded-xl font-bold hover:bg-slate-900 transition shadow-md active:scale-95">Sign In</button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] pb-24 font-sans selection:bg-[#1B4332] selection:text-white">
      {/* Premium Header */}
      <div className="bg-gradient-to-r from-[#0F2027] via-[#203A43] to-[#2C5364] text-white sticky top-0 z-10 shadow-xl shadow-slate-200/50">
        <div className="max-w-5xl mx-auto px-4 py-4 sm:px-6 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="bg-white/10 p-2 rounded-xl backdrop-blur-sm border border-white/20">
              <Package size={22} className="text-emerald-400" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-white/95">Venueza Sales</h1>
              <p className="text-[10px] text-emerald-400/90 font-bold uppercase tracking-widest">{user?.role} • {user?.name}</p>
            </div>
          </div>
          
          <div className="flex gap-2">
            <label className="group relative flex items-center justify-center bg-white/10 hover:bg-white/20 p-2.5 rounded-xl cursor-pointer transition-all border border-white/10 hover:border-white/30" title="Import Excel">
              <FileSpreadsheet size={18} className="text-emerald-300 group-hover:text-emerald-200" />
              <input type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={(e) => handleFileUpload(e, 'excel')} />
            </label>
            <label className="group relative flex items-center justify-center bg-white/10 hover:bg-white/20 p-2.5 rounded-xl cursor-pointer transition-all border border-white/10 hover:border-white/30" title="Import VCF Contacts">
              <Contact size={18} className="text-blue-300 group-hover:text-blue-200" />
              <input type="file" accept=".vcf" className="hidden" onChange={(e) => handleFileUpload(e, 'vcf')} />
            </label>
            <button onClick={handleLogout} className="group relative flex items-center justify-center bg-white/10 hover:bg-rose-500/40 p-2.5 rounded-xl cursor-pointer transition-all border border-white/10 hover:border-rose-500/50 ml-2" title="Logout">
              <LogOut size={18} className="text-slate-300 group-hover:text-white" />
            </button>
          </div>
        </div>

        {/* Search Bar */}
        <div className="max-w-5xl mx-auto px-4 sm:px-6 pb-5">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={18} className="text-slate-400" />
            </div>
            <input 
              type="text" 
              placeholder="Search clients by name or phone..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="block w-full pl-10 pr-3 py-3 border-0 rounded-2xl leading-5 bg-white/10 text-white placeholder-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-400 focus:bg-white/20 sm:text-sm backdrop-blur-md transition-all shadow-inner"
            />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 mt-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 relative overflow-hidden group hover:shadow-md transition-all">
            <div className="absolute -right-4 -top-4 w-16 h-16 bg-blue-50 rounded-full group-hover:scale-150 transition-transform duration-500"></div>
            <div className="relative">
              <div className="flex items-center gap-2 text-slate-500 mb-2">
                <Users size={16} />
                <p className="text-[10px] font-bold uppercase tracking-wider">Total Leads</p>
              </div>
              <p className="text-2xl font-black text-slate-800">{clients.length}</p>
            </div>
          </div>
          
          <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 relative overflow-hidden group hover:shadow-md transition-all">
            <div className="absolute -right-4 -top-4 w-16 h-16 bg-emerald-50 rounded-full group-hover:scale-150 transition-transform duration-500"></div>
            <div className="relative">
              <div className="flex items-center gap-2 text-slate-500 mb-2">
                <Activity size={16} className="text-emerald-500" />
                <p className="text-[10px] font-bold uppercase tracking-wider">Converted</p>
              </div>
              <p className="text-2xl font-black text-emerald-600">{clients.filter(c => c.status === 'Converted' || c.status === 'Completed').length}</p>
            </div>
          </div>
        </div>

        {/* Client List */}
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
            <UserPlus size={20} className="text-slate-400" /> Client Roster
          </h2>
          <div className="flex items-center gap-1 text-sm text-slate-500 font-medium">
            <Filter size={14} /> {filteredClients.length} found
          </div>
        </div>

        {loading ? (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="w-10 h-10 border-4 border-slate-200 border-t-[#1B4332] rounded-full animate-spin mb-4"></div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredClients.map(client => {
              const conf = statusConfig[client.status] || statusConfig['Lead'];
              return (
                <div key={client.id} onClick={() => openEdit(client)} className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 hover:border-emerald-200 hover:shadow-md cursor-pointer transition-all group active:scale-[0.98]">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex-1">
                      <h3 className="font-bold text-slate-800 text-lg leading-tight group-hover:text-emerald-700 transition-colors">{client.name}</h3>
                      {user?.role === 'Owner' && client.User && (
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Agent: {client.User.name}</p>
                      )}
                    </div>
                    <span className={`text-[10px] px-2 py-1 rounded-md font-bold border ${conf.bg} ${conf.text} ${conf.border}`}>
                      {client.status}
                    </span>
                  </div>
                  
                  <div className="flex gap-2 mb-3">
                    {client.package === 'Advanced' ? (
                      <span className="text-[10px] font-bold uppercase bg-amber-50 text-amber-700 px-2 py-0.5 rounded border border-amber-200">⭐ Advanced</span>
                    ) : (
                      <span className="text-[10px] font-bold uppercase bg-slate-50 text-slate-500 px-2 py-0.5 rounded border border-slate-200">Standard</span>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    {client.phone && (
                      <div className="flex items-center gap-2 text-sm text-slate-600 bg-slate-50 p-2 rounded-lg border border-slate-100">
                        <div className="bg-white p-1 rounded shadow-sm text-slate-400"><Phone size={14} /></div>
                        <span className="font-medium">{client.phone}</span>
                      </div>
                    )}
                    {client.email && (
                      <div className="flex items-center gap-2 text-sm text-slate-600 bg-slate-50 p-2 rounded-lg border border-slate-100">
                        <div className="bg-white p-1 rounded shadow-sm text-slate-400"><Mail size={14} /></div>
                        <span className="truncate">{client.email}</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
            
            {filteredClients.length === 0 && (
              <div className="col-span-full bg-white p-12 rounded-3xl border border-slate-100 text-center shadow-sm">
                <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4 border border-slate-100 shadow-inner">
                  <Users size={32} className="text-slate-300" />
                </div>
                <h3 className="text-lg font-bold text-slate-800 mb-1">No clients found</h3>
                <p className="text-slate-500 text-sm">Add a new client manually or import your existing contacts.</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Floating Action Button */}
      <button 
        onClick={() => { setEditingClient(null); setForm({ name: '', phone: '', email: '', package: 'Standard', status: 'Lead', notes: '' }); setShowAddModal(true); }}
        className="fixed bottom-6 right-6 bg-gradient-to-r from-emerald-500 to-teal-600 text-white p-4 rounded-2xl shadow-lg shadow-emerald-500/30 hover:shadow-xl hover:shadow-emerald-500/40 transition-all active:scale-95 z-20 flex items-center justify-center"
      >
        <Plus size={28} className="drop-shadow-md" />
      </button>

      {/* Add/Edit Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
          <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm transition-opacity" onClick={() => setShowAddModal(false)}></div>
          
          <div className="bg-white w-full sm:max-w-lg rounded-t-3xl sm:rounded-3xl shadow-2xl relative z-10 max-h-[90vh] flex flex-col animate-in slide-in-from-bottom-8 sm:slide-in-from-bottom-0 sm:zoom-in-95 duration-200">
            <div className="flex justify-between items-center p-5 border-b border-slate-100 bg-slate-50 rounded-t-3xl">
              <div>
                <h3 className="font-extrabold text-lg text-slate-800 tracking-tight">{editingClient ? 'Update Client' : 'New Lead'}</h3>
              </div>
              <button onClick={() => setShowAddModal(false)} className="bg-white hover:bg-slate-200 text-slate-500 p-2 rounded-full transition-colors shadow-sm">
                <X size={18} />
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5 ml-1">Client Name</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400"><Users size={16} /></div>
                  <input required type="text" value={form.name} onChange={e => setForm({...form, name: e.target.value})} className="block w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-sm focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none" placeholder="Acme Corp" />
                </div>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5 ml-1">Phone</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400"><Phone size={16} /></div>
                    <input type="tel" value={form.phone} onChange={e => setForm({...form, phone: e.target.value})} className="block w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-sm focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none" placeholder="+91 98765..." />
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5 ml-1">Email</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400"><Mail size={16} /></div>
                    <input type="email" value={form.email} onChange={e => setForm({...form, email: e.target.value})} className="block w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-sm focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none" placeholder="email@domain.com" />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5 ml-1">Lead Status</label>
                <select value={form.status} onChange={e => setForm({...form, status: e.target.value})} className="block w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-sm font-medium focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none appearance-none">
                  {allStatuses.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5 ml-1">Subscription Package</label>
                <div className="flex gap-2">
                  <label className={`flex-1 cursor-pointer p-3 border rounded-xl text-center text-sm font-bold transition-all ${form.package === 'Standard' ? 'border-slate-800 bg-slate-800 text-white' : 'border-slate-200 bg-slate-50 text-slate-500 hover:bg-slate-100'}`}>
                    <input type="radio" name="package" value="Standard" className="hidden" onChange={e => setForm({...form, package: e.target.value})} checked={form.package === 'Standard'} />
                    Standard
                  </label>
                  <label className={`flex-1 cursor-pointer p-3 border rounded-xl text-center text-sm font-bold transition-all ${form.package === 'Advanced' ? 'border-amber-500 bg-amber-500 text-white' : 'border-slate-200 bg-slate-50 text-slate-500 hover:bg-slate-100'}`}>
                    <input type="radio" name="package" value="Advanced" className="hidden" onChange={e => setForm({...form, package: e.target.value})} checked={form.package === 'Advanced'} />
                    Advanced
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5 ml-1">Notes</label>
                <textarea rows="3" value={form.notes || ''} onChange={e => setForm({...form, notes: e.target.value})} className="block w-full p-4 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-sm focus:ring-2 focus:ring-emerald-500/20 outline-none resize-none" placeholder="Meeting details, requirements..."></textarea>
              </div>
              
              <div className="pt-2">
                <button type="submit" className="w-full bg-slate-800 hover:bg-slate-900 text-white p-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-md active:scale-95">
                  <Save size={18} /> {editingClient ? 'Save Changes' : 'Create Lead'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
