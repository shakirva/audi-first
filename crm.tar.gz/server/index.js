require('dotenv').config();
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const xlsx = require('xlsx');
const vcf = require('vcard-parser');
const fs = require('fs');
const { sequelize, Client } = require('./models');

const app = express();
app.use(cors());
app.use(express.json());

const upload = multer({ dest: 'uploads/' });

// Get all clients
app.get('/api/clients', async (req, res) => {
  try {
    const clients = await Client.findAll({ order: [['createdAt', 'DESC']] });
    res.json(clients);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Add client
app.post('/api/clients', async (req, res) => {
  try {
    const client = await Client.create(req.body);
    res.json(client);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update client
app.put('/api/clients/:id', async (req, res) => {
  try {
    const client = await Client.findByPk(req.params.id);
    if (!client) return res.status(404).json({ error: 'Client not found' });
    await client.update(req.body);
    res.json(client);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Import Excel
app.post('/api/import/excel', upload.single('file'), async (req, res) => {
  try {
    const workbook = xlsx.readFile(req.file.path);
    const sheet_name_list = workbook.SheetNames;
    const data = xlsx.utils.sheet_to_json(workbook.Sheets[sheet_name_list[0]]);
    
    let imported = 0;
    for (const row of data) {
      if (row.Name || row.name) {
        await Client.create({
          name: row.Name || row.name,
          phone: String(row.Phone || row.phone || ''),
          email: row.Email || row.email || '',
          package: row.Package || row.package || 'Standard',
          status: 'Lead',
          notes: row.Notes || row.notes || ''
        });
        imported++;
      }
    }
    fs.unlinkSync(req.file.path);
    res.json({ message: `Imported ${imported} clients successfully` });
  } catch (err) {
    if (req.file) fs.unlinkSync(req.file.path);
    res.status(500).json({ error: err.message });
  }
});

// Import VCF
app.post('/api/import/vcf', upload.single('file'), async (req, res) => {
  try {
    const vcfData = fs.readFileSync(req.file.path, 'utf8');
    const parsed = vcf.parse(vcfData);
    
    let imported = 0;
    // vCard parser returns a complex object, we'll try to extract simple contacts
    // Note: VCF structure can be tricky, this is a basic parser fallback
    const lines = vcfData.split('\n');
    let currentContact = null;
    
    for (let line of lines) {
      line = line.trim();
      if (line.startsWith('BEGIN:VCARD')) {
        currentContact = { name: 'Unknown', phone: '' };
      } else if (line.startsWith('FN:')) {
        currentContact.name = line.substring(3);
      } else if (line.startsWith('TEL')) {
        const phoneParts = line.split(':');
        if (phoneParts.length > 1) {
          currentContact.phone = phoneParts[1];
        }
      } else if (line.startsWith('END:VCARD')) {
        if (currentContact) {
          await Client.create({
            name: currentContact.name,
            phone: currentContact.phone,
            status: 'Lead'
          });
          imported++;
        }
      }
    }
    
    fs.unlinkSync(req.file.path);
    res.json({ message: `Imported ${imported} contacts successfully` });
  } catch (err) {
    if (req.file) fs.unlinkSync(req.file.path);
    res.status(500).json({ error: err.message });
  }
});

const PORT = process.env.PORT || 5007;
sequelize.sync().then(() => {
  app.listen(PORT, () => console.log(`CRM API running on port ${PORT}`));
});
