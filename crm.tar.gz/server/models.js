const { Sequelize, DataTypes } = require('sequelize');

const sequelize = new Sequelize(process.env.DATABASE_URL || 'postgres://postgres:postgres@localhost:5432/venueza_crm', {
  dialect: 'postgres',
  logging: false,
});

const Client = sequelize.define('Client', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  name: { type: DataTypes.STRING, allowNull: false },
  phone: { type: DataTypes.STRING },
  email: { type: DataTypes.STRING },
  package: { type: DataTypes.ENUM('Standard', 'Advanced'), defaultValue: 'Standard' },
  status: { type: DataTypes.ENUM('Lead', 'Follow-up', 'Converted', 'Lost'), defaultValue: 'Lead' },
  notes: { type: DataTypes.TEXT },
});

module.exports = { sequelize, Client };
