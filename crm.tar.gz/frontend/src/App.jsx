import { useState, useEffect } from 'react';
import { getClients, addClient, updateClient, importExcel, importVCF } from './api';
import { Users, Upload, Plus, Phone, Mail, Package, AlertCircle, Save, X } from 'lucide-react';

function App() {
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingClient, setEditingClient] = useState(null);
  
  const [form, setForm] = useState({ name: '', phone: '', email: '', package: 'Standard', status: 'Lead', notes: '' });

  useEffect(() => {
    fetchClients();
  }, []);

  const fetchClients = async () => {
    try {
      const { data } = await getClients();
      setClients(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (editingClient) {
      await updateClient(editingClient.id, form);
    } else {
      await addClient(form);
    }
    setShowAddModal(false);
    setEditingClient(null);
    setForm({ name: '', phone: '', email: '', package: 'Standard', status: 'Lead', notes: '' });
    fetchClients();
  };

  const handleFileUpload = async (e, type) => {
    const file = e.target.files[0];
    if (!file) return;
    
    const formData = new FormData();
    formData.append('file', file);
    
    try {
      if (type === 'excel') {
        await importExcel(formData);
      } else {
        await importVCF(formData);
      }
      alert('Import successful!');
      fetchClients();
    } catch (err) {
      alert('Failed to import file');
    }
    e.target.value = null; // reset
  };

  const openEdit = (client) => {
    setForm(client);
    setEditingClient(client);
    setShowAddModal(true);
  };

  const statusColors = {
    'Lead': 'bg-blue-100 text-blue-800',
    'Follow-up': 'bg-yellow-100 text-yellow-800',
    'Converted': 'bg-green-100 text-green-800',
    'Lost': 'bg-red-100 text-red-800'
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-[#1B4332] text-white p-4 sticky top-0 z-10 shadow-md">
        <div className="flex justify-between items-center max-w-4xl mx-auto">
          <div className="flex items-center gap-2">
            <Package size={24} />
            <h1 className="text-xl font-bold font-serif tracking-wide">Venueza Sales CRM</h1>
          </div>
          <div className="flex gap-2">
            <label className="bg-white/20 p-2 rounded-full cursor-pointer hover:bg-white/30 transition">
              <Upload size={18} />
              <input type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={(e) => handleFileUpload(e, 'excel')} />
            </label>
            <label className="bg-white/20 p-2 rounded-full cursor-pointer hover:bg-white/30 transition">
              <Users size={18} />
              <input type="file" accept=".vcf" className="hidden" onChange={(e) => handleFileUpload(e, 'vcf')} />
            </label>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-4 max-w-4xl mx-auto">
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
            <p className="text-xs text-gray-500 font-bold uppercase tracking-wider mb-1">Total Leads</p>
            <p className="text-2xl font-bold text-gray-900">{clients.length}</p>
          </div>
          <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
            <p className="text-xs text-gray-500 font-bold uppercase tracking-wider mb-1">Converted</p>
            <p className="text-2xl font-bold text-green-600">{clients.filter(c => c.status === 'Converted').length}</p>
          </div>
        </div>

        {loading ? (
          <p className="text-center text-gray-500 mt-10">Loading clients...</p>
        ) : (
          <div className="space-y-3">
            {clients.map(client => (
              <div key={client.id} onClick={() => openEdit(client)} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 cursor-pointer active:scale-95 transition">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-bold text-gray-900 text-lg">{client.name}</h3>
                  <span className={`text-xs px-2 py-1 rounded-full font-bold ${statusColors[client.status]}`}>
                    {client.status}
                  </span>
                </div>
                <div className="flex items-center gap-4 text-sm text-gray-600 mb-2">
                  {client.phone && <span className="flex items-center gap-1"><Phone size={14} /> {client.phone}</span>}
                  {client.email && <span className="flex items-center gap-1"><Mail size={14} /> {client.email}</span>}
                </div>
                <div className="flex justify-between items-center">
                  <span className={`text-xs font-bold px-2 py-1 rounded border ${client.package === 'Advanced' ? 'border-purple-200 text-purple-700 bg-purple-50' : 'border-gray-200 text-gray-700 bg-gray-50'}`}>
                    {client.package} Package
                  </span>
                </div>
              </div>
            ))}
            {clients.length === 0 && (
              <div className="text-center mt-10 text-gray-400">
                <Users size={48} className="mx-auto mb-3 opacity-20" />
                <p>No clients yet. Add one or import from Excel/VCF.</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* FAB */}
      <button 
        onClick={() => { setEditingClient(null); setForm({ name: '', phone: '', email: '', package: 'Standard', status: 'Lead', notes: '' }); setShowAddModal(true); }}
        className="fixed bottom-6 right-6 bg-[#1B4332] text-white p-4 rounded-full shadow-lg hover:shadow-xl transition active:scale-90"
      >
        <Plus size={24} />
      </button>

      {/* Add/Edit Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="bg-white w-full sm:max-w-md rounded-t-2xl sm:rounded-2xl overflow-hidden animate-slide-up">
            <div className="flex justify-between items-center p-4 border-b border-gray-100 bg-gray-50">
              <h3 className="font-bold text-gray-900">{editingClient ? 'Edit Client' : 'New Client'}</h3>
              <button onClick={() => setShowAddModal(false)} className="text-gray-400 hover:text-gray-600"><X size={20} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-4 space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Name</label>
                <input required type="text" value={form.name} onChange={e => setForm({...form, name: e.target.value})} className="w-full p-3 border border-gray-200 rounded-xl focus:border-[#1B4332] focus:ring-1 focus:ring-[#1B4332] outline-none transition" placeholder="Client Name" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Phone</label>
                  <input type="tel" value={form.phone} onChange={e => setForm({...form, phone: e.target.value})} className="w-full p-3 border border-gray-200 rounded-xl outline-none" placeholder="Phone Number" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Package</label>
                  <select value={form.package} onChange={e => setForm({...form, package: e.target.value})} className="w-full p-3 border border-gray-200 rounded-xl outline-none bg-white">
                    <option>Standard</option>
                    <option>Advanced</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Status</label>
                <select value={form.status} onChange={e => setForm({...form, status: e.target.value})} className="w-full p-3 border border-gray-200 rounded-xl outline-none bg-white">
                  <option>Lead</option>
                  <option>Follow-up</option>
                  <option>Converted</option>
                  <option>Lost</option>
                </select>
              </div>
              <button type="submit" className="w-full bg-[#1B4332] text-white p-4 rounded-xl font-bold flex items-center justify-center gap-2 mt-2">
                <Save size={18} /> {editingClient ? 'Save Changes' : 'Save Client'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
